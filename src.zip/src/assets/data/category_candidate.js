const initialCategories = [
  {
    id: "female",
    name: "Best Female Artist",
    candidates: [
      { id: 1, name: "IU", photo: "iu.png" },
      { id: 2, name: "IU", photo: "iu.png" },
      { id: 3, name: "IU", photo: "iu.png" },
      { id: 4, name: "IU", photo: "iu.png" },
      { id: 5, name: "IU", photo: "iu.png" },
      { id: 6, name: "IU", photo: "iu.png" },
      { id: 7, name: "IU", photo: "iu.png" },
    ],
  },
  {
    id: "male",
    name: "Best Male Artist",
    candidates: [
      { id: "f1", name: "IU", photo: "iu.png" },
      { id: "f2", name: "IU", photo: "iu.png" },
      { id: "f3", name: "IU", photo: "iu.png" },
      { id: "f4", name: "IU", photo: "iu.png" },
      { id: "f5", name: "IU", photo: "iu.png" },
      { id: "f6", name: "IU", photo: "iu.png" },
      { id: "f7", name: "IU", photo: "iu.png" },
    ],
  },
  {
    id: "collab",
    name: "Best Collaboration",
    candidates: [
      { id: "f1", name: "IU", photo: "iu.png" },
      { id: "f2", name: "IU", photo: "iu.png" },
      { id: "f3", name: "IU", photo: "iu.png" },
      { id: "f4", name: "IU", photo: "iu.png" },
      { id: "f5", name: "IU", photo: "iu.png" },
      { id: "f6", name: "IU", photo: "iu.png" },
      { id: "f7", name: "IU", photo: "iu.png" },
    ],
  },
];

export default initialCategories;

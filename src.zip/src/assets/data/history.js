const history = [
    {
        email: "user@gmail.com",
        vote: [
            { category: "Best Female", name: "IU", photo: "iu.png" },
            { category: "Best Male", name: "TXT", photo: "iu.png" },
            { category: "Best Collaboration", name: "Zico", photo: "iu.png" },
        ]
    }
];

export default history;
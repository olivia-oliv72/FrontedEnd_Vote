const roleUsers = [
  {
    id: 1,
    username: "admin",
    password: "admin123",
    role: "admin",
  },
  {
    id: 2,
    username: "user1",
    password: "user123",
    email: "user@gmail.com",
    role: "user",
  }
];

export default roleUsers;
import "../assets/css/guest/Home.css"

export default function footer () {
    return (
        <div class="footer">
            Thank you for supporting your favorite artists. © 2025 Artist Award.
        </div>
    )
}